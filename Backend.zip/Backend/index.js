const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');


const uploadRouter = require('./routes/upload');
const activitiesRouter = require('./routes/activities');


const app = express();
const PORT = process.env.PORT || 4000;


app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


// ensure uploads folder
if (!fs.existsSync(path.join(__dirname, 'uploads'))) fs.mkdirSync(path.join(__dirname, 'uploads'));


app.use('/api/upload', uploadRouter);
app.use('/api/activities', activitiesRouter);


app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));