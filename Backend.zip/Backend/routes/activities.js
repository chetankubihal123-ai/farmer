const express = require('express');
const path = require('path');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');

const router = express.Router();

const dbFile = path.join(__dirname, '..', 'db.json');
const adapter = new JSONFile(dbFile);
const defaultData = { users: {}, activities: [] };
const db = new Low(adapter, defaultData);

async function ensureDB() {
  await db.read();
  db.data ||= defaultData;
  await db.write();
}

// Initialize DB
(async () => { await ensureDB(); })();

router.get('/list', async (req, res) => {
  await ensureDB();
  
  const userId = req.query.userId || 'demo_farm_1';
  const activities = db.data.activities
    .filter(a => a.userId === userId)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const user = db.data.users[userId] || { credits: 0, efficiencyHistory: [] };

  res.json({ activities, user });
});

module.exports = router;
