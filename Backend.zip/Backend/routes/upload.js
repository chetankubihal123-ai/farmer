const express = require('express');
const multer = require('multer');
const path = require('path');
const { nanoid } = require('nanoid');
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');
const { classifyImage } = require('../utils/classifier');

const router = express.Router();

const dbFile = path.join(__dirname, '..', 'db.json');
const adapter = new JSONFile(dbFile);
const defaultData = { users: {}, activities: [] };
const db = new Low(adapter, defaultData);

async function ensureDB() {
  await db.read();
  db.data ||= defaultData;
  await db.write();
}

// Initialize DB
(async () => { await ensureDB(); })();

const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename(req, file, cb) {
    const id = nanoid(8);
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}_${id}${ext}`);
  }
});

const upload = multer({ storage });

router.post('/one', upload.single('file'), async (req, res) => {
  await ensureDB();
  const file = req.file;
  const { text, lat, lng, userId } = req.body;

  if (!file) return res.status(400).json({ error: 'file required' });

  const { label, confidence } = await classifyImage(file.path, file.originalname);

  const activity = {
    id: nanoid(10),
    userId: userId || 'demo_farm_1',
    fileUrl: `/uploads/${file.filename}`,
    originalName: file.originalname,
    text: text || '',
    label,
    confidence,
    lat: lat || null,
    lng: lng || null,
    timestamp: new Date().toISOString(),
    credits: computeCredits(label, confidence)
  };

  db.data.activities.push(activity);

  db.data.users[activity.userId] ||= { credits: 0, efficiencyHistory: [] };
  db.data.users[activity.userId].credits += activity.credits;
  db.data.users[activity.userId].efficiencyHistory.push({
    timestamp: activity.timestamp,
    score: activity.credits
  });

  await db.write();

  res.json({ activity });
});

function computeCredits(label, confidence) {
  const base = { watering: 5, weeding: 7, seeding: 10, pest_check: 8, unknown: 1 };
  const b = base[label] || 2;
  return Math.round(b * Math.max(0.3, confidence));
}

module.exports = router;
