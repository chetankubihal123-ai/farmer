// classifier.js
// Input: path to file; Output: { label: 'watering'|'weeding'|'seeding'|'pest_check'|'unknown', confidence: 0-1 }


const keywords = {
watering: ['water', 'watering', 'hose', 'sprinkler'],
weeding: ['weed', 'weeding'],
seeding: ['seed', 'sowing', 'seeding'],
pest_check: ['pest', 'spray', 'insect']
};


async function classifyImage(filePath, filename) {
// Very fast local heuristic: check filename or randomly choose
const name = (filename || '').toLowerCase();
for (const label of Object.keys(keywords)) {
for (const kw of keywords[label]) {
if (name.includes(kw)) return { label, confidence: 0.95 };
}
}


// fallback: random but deterministic-ish by file size
try {
const stats = require('fs').statSync(filePath);
const v = (stats.size % 100) / 100; // 0..0.99
const labels = Object.keys(keywords);
const label = labels[Math.floor(v * labels.length)];
return { label, confidence: 0.6 + (v * 0.4) };
} catch (e) {
return { label: 'unknown', confidence: 0.3 };
}
}


module.exports = { classifyImage };